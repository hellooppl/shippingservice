shipping_list = []
delivery_list = []
