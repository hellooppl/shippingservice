from typing import Text
from sanic import Sanic
import os
from sanic.response import text, json
from ..domain import commands

app = Sanic(__name__)

@app.route("/shipping", methods=['POST'])
async def add_shipping(request):
    cmd = commands.AddShipping(
        category=request.json["category"],
        cost=request.json["cost"],
        regionId=request.json["regionId"],
        orderId=request.json["orderId"],
        insurance=request.json["insurance"],
        date_to_ship= request.json["date_to_ship"]
        )
    uow = unit_of_work.ShippingUOW
    await messagebus.handle(cmd, uow)
    return Text("success")


@app.route('/shipping/'+<int>, methods=['GET'])
async def get_shipping(request,id):
    cmd = commands.GetShipping(
        _id=id
    )
    uow=unit_of_work.ShippingUOW
    await messagebus.handle(cmd,uow)
    return Text("success")


@app.route('/allocate', methods=['PUT','PATCH'])
async def allocate_shipping(request):
        cmd = commands.UpdateTask(
            _id:request.json["user_id"],
            task:request.json["shipping_id"]
        )
        uow=unit_of_work.DeliveryUOW
        await messagebus.handle(cmd,uow)
    return Text('success')


if __name__ == "__main__":
    s = os.path.abspath("service_layer")
    print(s)
    app.run(debug=True)