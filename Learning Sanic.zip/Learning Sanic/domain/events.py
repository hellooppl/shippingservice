from uuid import UUID
class Event(BaseModel):
    pass


class NotAvailable(Event):
    user:UUID

